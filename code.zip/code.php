<?php
/*
 * Plugin Name: My plugin example
 */

 /*
 * Plugin Name:       My Plugin
 * Author:            Umayr Nordien
 */

// Remove the admin bar from the front end
add_filter( 'show_admin_bar', '__return_false' );